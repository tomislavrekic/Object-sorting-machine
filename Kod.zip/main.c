/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

TIM_HandleTypeDef htim1;

UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
uint8_t tx_buff[2];
volatile uint8_t rx_buff[MESSAGE_PROTOCOL_SIZE];
volatile uint8_t msg_protocol[MESSAGE_PROTOCOL_SIZE];
volatile uint8_t det_obj_buff[3];
volatile uint8_t sys_flag = 0;
volatile uint8_t sys_flag_changed = 0;

uint32_t conveyor_sensor, shaker_sensor;
uint8_t conveyor_flag, shaker_flag;
int m,j;

typedef enum {
	cube = 1,
	cylinder = 2,
	prism = 3,
	pyramid = 4,
	sphere = 5,
}OBJECT_SHAPE_E;

typedef enum {
	blue = 1,
	green = 2,
	red = 3,
	yellow =4,
}OBJECT_COLOR_E;

struct Object_properties{
	OBJECT_SHAPE_E shape;
	OBJECT_COLOR_E color;
	int16_t mass;
};

struct Container_properties{
	OBJECT_SHAPE_E shape;
	OBJECT_COLOR_E color;
	int min_mass;
	int max_mass;
};

struct Object_properties Object;

struct Container_properties Container[3];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM1_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */

void Set_Start_Positions();
int Read_Char3(uint8_t* char_array, int idx);
void Define_Containers();
void Define_Object();
void Choos_Container();
void Move_To_Container();
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  __HAL_UART_ENABLE_IT(&huart1, UART_IT_RXNE);
  Set_Start_Positions();
  HAL_Delay(250);
  SCALE_init();

  conveyor_flag = 0;
  shaker_flag = 0;

  //SCALE_init();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1) {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	if(sys_flag_changed){
		if(sys_flag){
			Set_Start_Positions();
			Define_Containers();
			sys_flag_changed = 0;

		}
		}


	if(sys_flag == 1){

		SERVO_setPosition(SERVO_1, 132);
		HAL_Delay(1000);
		SERVO_setPosition(SERVO_1, 36);
		HAL_Delay(200);

		for(j=0;j < 3;j++){
			conveyor_sensor = analogRead(SENSOR_1);
			if(conveyor_flag == 0){
				HAL_GPIO_WritePin(GPIOB, DC_MOTOR_1_Pin, SET);
				for(m=0;m<320000;m++){
					if(conveyor_sensor > 1100){
						break;
					}
					if(sys_flag==0){
						shaker_flag=0;
						break;
					}
					conveyor_sensor = analogRead(SENSOR_1);
				}
				HAL_GPIO_WritePin(GPIOB, DC_MOTOR_1_Pin, RESET);
				conveyor_flag = 1;
			}
			HAL_Delay(500);
			shaker_sensor = analogRead(SENSOR_2);
			if(shaker_flag == 0){
				HAL_GPIO_WritePin(GPIOB, DC_MOTOR_2_Pin, SET);
				for(m=0;m<500000;m++){
					if(shaker_sensor > 500){
						break;
					}
					if(sys_flag==0){
						break;
					}
					shaker_sensor = analogRead(SENSOR_2);
				}
				HAL_Delay(500);
				HAL_GPIO_WritePin(GPIOB, DC_MOTOR_2_Pin, RESET);
				shaker_flag = 1;
			}

			Object.mass = SCALE_getMass();
			det_obj_buff[2] = 0;

			HAL_Delay(500);
			HAL_GPIO_WritePin(GPIOB, USART_FLG_Pin, SET);
			HAL_Delay(500);
			HAL_GPIO_WritePin(GPIOB, USART_FLG_Pin, RESET);

			for(m=0;m<3000000;m++){
				if(det_obj_buff[2] == '#'){
					break;
				}
				if(sys_flag==0){
					break;
					}
				}

			Define_Object();
			det_obj_buff[2] = 0;

			Choos_Container();
			Move_To_Container();

			HAL_Delay(1000);
			shaker_flag = 0;
			conveyor_flag = 0;
			if(sys_flag==0){
				break;
				}
			}
		}
    }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV4;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */
  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_13CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 71;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 10000;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 750;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ON_BOARD_LED_GPIO_Port, ON_BOARD_LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SCALE_SCK_GPIO_Port, SCALE_SCK_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, DC_MOTOR_1_Pin|DC_MOTOR_2_Pin|CAMERA_LIGHT_Pin|USART_FLG_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : ON_BOARD_LED_Pin */
  GPIO_InitStruct.Pin = ON_BOARD_LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(ON_BOARD_LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : SCALE_SCK_Pin */
  GPIO_InitStruct.Pin = SCALE_SCK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(SCALE_SCK_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : SCALE_DT_Pin */
  GPIO_InitStruct.Pin = SCALE_DT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(SCALE_DT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : DC_MOTOR_1_Pin DC_MOTOR_2_Pin CAMERA_LIGHT_Pin USART_FLG_Pin */
  GPIO_InitStruct.Pin = DC_MOTOR_1_Pin|DC_MOTOR_2_Pin|CAMERA_LIGHT_Pin|USART_FLG_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */


void Set_Start_Positions(){
	SERVO_setPosition(SERVO_1, 36);
	SERVO_setPosition(SERVO_2, 40);
	SERVO_setPosition(SERVO_3, 40);
	HAL_GPIO_WritePin(GPIOB, DC_MOTOR_1_Pin, RESET);
	HAL_GPIO_WritePin(GPIOB, DC_MOTOR_2_Pin, RESET);
	HAL_GPIO_WritePin(GPIOB, USART_FLG_Pin, RESET);
	conveyor_flag = 0;
	shaker_flag = 0;
}
int Read_Char3(uint8_t* char_array, int idx){

	int int_num = 0;
	int_num += (char_array[idx]-48)*100;
	int_num += (char_array[idx+1]-48)*10;
	int_num += (char_array[idx+2]-48);
	return int_num;
}

void Define_Containers(){
	int k = 0;
	for(k=0; k<3; k++){
		Container[k].shape = msg_protocol[1+9*k]-48;
		Container[k].color = msg_protocol[2+9*k]-48;
		Container[k].min_mass = Read_Char3(msg_protocol,3+9*k);
		Container[k].max_mass = Read_Char3(msg_protocol,6+9*k);
	}
	k = 0;
}

void Define_Object(){
	HAL_Delay(100);
	Object.shape = det_obj_buff[0]-48;
	Object.color = det_obj_buff[1]-48;
	det_obj_buff[0]=9;
	det_obj_buff[1]=9;
}

void Choos_Container(){

	//set to 'other' container
	int container_index = 3;
	int num_matches = 0;
	int max_num_matches = 0;
	int idx = 0;
	int deg = 160;

	for (idx=0;idx<3;idx++){
		num_matches = 0;
		if(Container[idx].color == Object.color){
			num_matches ++;
		}
		if(Container[idx].shape == Object.shape){
			num_matches ++;
		}
		if(Container[idx].min_mass >= Object.mass && Container[idx].max_mass <= Object.mass){
			num_matches ++;
		}
		if(num_matches > max_num_matches){
			max_num_matches = num_matches;
			container_index = idx;
		}
	}
	if (container_index == 0){
		deg = 160;
	}
	else if (container_index == 1){
		deg = 120;
	}
	else if (container_index == 2){
		deg = 80;
	}
	else {
		deg = 40;
	}

	SERVO_setPosition(SERVO_3, deg);
	HAL_Delay(2500);
}

void Move_To_Container(){
	SERVO_setPosition(SERVO_2, 150);
	HAL_Delay(200);
	SERVO_setPosition(SERVO_2, 160);
	HAL_Delay(200);
	SERVO_setPosition(SERVO_2, 170);
	HAL_Delay(700);
	SERVO_setPosition(SERVO_2, 40);
	HAL_Delay(200);
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
    /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
    /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
