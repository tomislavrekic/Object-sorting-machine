from PIL import Image
import numpy as np
import glob
import cv2

###############CONSTANTS################
blue_space = ((100, 100, 20), (140, 255, 255))
green_space = ((40, 100, 20), (80, 255, 255))
red_space = ((0, 100, 20), (10, 255, 255))
yellow_space = ((20, 100, 20), (40, 255, 255))
color_spaces = [blue_space, green_space, red_space, yellow_space]
color_name = ['blue', 'green', 'red', 'yellow']
#########################################

def crop_padding(x, y, w, h, img_w, img_h, CROP_PADDING=5):
    """Add padding around copped image by changing the crop coordinates."""

    x -= CROP_PADDING
    if x<=0:
        x=0
    y -= CROP_PADDING
    if y<=0:
        y=0
        
    w += 2*CROP_PADDING
    if x+w > img_w:
        w = img_w-x

    h += 2*CROP_PADDING
    if y+h > img_h:
        h = img_h-y

    return x,y,w,h

def crop_center(h, w, CROP_PROC = 0.2):
    """Crop the centre of an image""" 

    x = int(CROP_PROC*w)
    y = int(CROP_PROC*h)
    w -= int(CROP_PROC*2*w)
    h -= int(CROP_PROC*2*h)

    return x,y,w,h

def define_object(img, MIN_IMG_SIZE=150):
    """
    Crop objects from img and find its color.
    - search for object by color
    - return:
        -crop of object
        -object color name
        -color rgb value
    """ 
    max_area_contour = None
    object_color = None
    max_mask = None
    max_area = 0
    
    img_h, img_w, _ = img.shape
    x,y,w,h = crop_center(img_h, img_w, 0.23)
    img=img[y:y+h,x:x+w]
    img = cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
    
    img = cv2.convertScaleAbs(img, alpha=1.7, beta=0)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    
    for color_id, space in enumerate(color_spaces):
        mask = cv2.inRange(hsv,space[0],space[1])
        medianFiltered = cv2.medianBlur(mask,5)
        _, contours, hierarchy = cv2.findContours(medianFiltered,
                         cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        for contour in contours:
            area = cv2.contourArea(contour)
            #print(area)
            if area > MIN_IMG_SIZE and max_area < area:
                max_area_contour = contour
                max_mask = mask
                max_area = area
                object_color = color_id
                
    if  max_area == 0:
        print("WARNING: No objects detected")
        return None, None

    x,y,w,h = cv2.boundingRect(max_area_contour)
    x,y,w,h = crop_padding(x,y,w,h,img_w,img_h)
    image_cropped=img[y:y+h,x:x+w]
    image_cropped=cv2.resize(image_cropped, (224,224))

    imask = max_mask>0
    sliced_img = np.zeros_like(img, np.uint8)
    sliced_img[imask] = img[imask]
    
    new_img_gray = cv2.cvtColor(image_cropped, cv2.COLOR_BGR2GRAY)
    #repating grayscale first channel as in the keras datagen
    new_img_gray_3c = np.repeat(new_img_gray[..., np.newaxis], 3, -1)

    return new_img_gray_3c, object_color

def get_dominant_color(img):
    """Returnes the dominant color in img"""
    
    h, w, _ = img.shape
    x,y,w,h = crop_center(w, h)

    img_roi=img[y:y+h,x:x+w]
    img_roi=cv2.resize(img_roi, (25,25))

    a2D = img_roi.reshape(-1, img_roi.shape[-1])
    col_range = (256, 256, 256)
    a1D = np.ravel_multi_index(a2D.T, col_range)
    color_rgb = np.unravel_index(np.bincount(a1D).argmax(), col_range)
    
    col = np.zeros((300, 300, 3), np.uint8)
    col[:] = color_rgb
	
    return color_rgb




