import cv2
import numpy as np
from PIL import Image
import glob

MIN_IMG_SIZE = 50

SAVE_GRAY = 1
FIND_DOMINANT_COLOR = 0

#cube, prism, sphere, cylinder, pyramid
shape_list = ['prism']
SHAPE = shape_list[0]

def bincount_app(a):
    a2D = a.reshape(-1,a.shape[-1])
    col_range = (256, 256, 256) # generically : a2D.max(0)+1
    a1D = np.ravel_multi_index(a2D.T, col_range)
    return np.unravel_index(np.bincount(a1D).argmax(), col_range)

def crop_center(x, y, w, h, CROP_PROC = 0.05):
	x += int(CROP_PROC*w)
	y += int(CROP_PROC*h)
	w -= int(CROP_PROC*2*w)
	h -= int(CROP_PROC*2*h)
	return x,y,w,h


def crop_padding(x, y, w, h, img_w, img_h, CROP_PADDING=5):
    """Add padding around copped image by changing the crop coordinates."""

    x -= CROP_PADDING
    if x<=0:
        x=0
    y -= CROP_PADDING
    if y<=0:
        y=0
        
    w += 2*CROP_PADDING
    if x+w > img_w:
        w = img_w-x

    h += 2*CROP_PADDING
    if y+h > img_h:
        h = img_h-y

    return x,y,w,h


for shapes in shape_list:
	image_list = []
	for filename in glob.glob('geo_crop/images/'+shapes+'/*.jpg'): #assuming gif
	    image_list.append(filename)

	alpha = 1.9 # Contrast control (1.0-3.0)
	beta = 0 # Brightness control (0-100)

	idx = 0
	drr = 1

	for img_name in image_list:

		print('Image num: ' + str(drr))

		image = cv2.imread(img_name)
		#increase contrast to filter out background color
		image_con = cv2.convertScaleAbs(image, alpha=alpha, beta=beta)
		img_h, img_w, _ = image.shape

		
		hsv = cv2.cvtColor(image_con, cv2.COLOR_BGR2HSV)
		hsv[...,1] = hsv[...,1]*0.8 #change the saturation
		#hsv[...,2] = hsv[...,2]*1.6 #change brightness

		hue, saturation, value = cv2.split(hsv)
		retval, thresholded = cv2.threshold(saturation, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
		medianFiltered = cv2.medianBlur(thresholded,3)

		contours, _ = cv2.findContours(medianFiltered, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

		contour_list = []
		for contour in contours:
			area = cv2.contourArea(contour)
			if area > 100 and area < img_h*img_w*0.80:
				contour_list.append(contour)
		
		#cv2.drawContours(image_con, contour_list,  -1, (255,0,0), 2)
		#cv2.imshow('Objects Detected',image)
		#cv2.waitKey(0)
		
		for obj in contours:
			x,y,w,h = cv2.boundingRect(obj)
			x,y,w,h = crop_padding(x,y,w,h,img_w,img_h)

			#print(w,h)
			if w>MIN_IMG_SIZE and h>MIN_IMG_SIZE:
				idx+=1
				new_img=image[y:y+h,x:x+w]

				cv2.imwrite(r'geo_crop/data_rgb/'+shapes+'/img_'+str(idx)+'.png', new_img)
				if SAVE_GRAY == 1:
					gray=cv2.cvtColor(new_img,cv2.COLOR_BGR2GRAY)
					cv2.imwrite('geo_crop/data_gray/'+shapes+'/img_'+str(idx)+'.png', gray)

				if FIND_DOMINANT_COLOR == 1:
					x,y,w,h = crop_center(x,y,w,h)
					new_img_roi=image[y:y+h,x:x+w]
					#cv2.imshow("roi"+str(idx), new_img_roi)

					#image_color = np.zeros((300, 300, 3), np.uint8)
					color = bincount_app(new_img_roi)
					#image_color[:] = (color)
					print(color)
					#cv2.imshow(str(idx), image_color)
					#cv2.waitKey(0)
		if 1:
			cv2.imshow("check",image_con)
			cv2.waitKey()
			cv2.imshow("check",hsv)
			cv2.waitKey()
			cv2.imshow("check",medianFiltered)
			cv2.waitKey()
			cv2.imshow("check",new_img)
			cv2.waitKey()
				

		drr+=1
		#if drr==10:exit()
	print(idx)
	print("End!")
