import image_classification
import image_util

import numpy as np
import picamera
import picamera.array
import time
import io

from PIL import Image
from tflite_runtime.interpreter import Interpreter

model_path = 'geo_gray.tflite'
labels_path = 'geo_lable.txt'
interpreter = None

def setup():
    global interpreter    
    labels = image_classification.load_labels(labels_path)
    interpreter = Interpreter(model_path)
    input_details = interpreter.get_input_details()
    interpreter.resize_tensor_input(
        input_details[0]['index'], (1, 224, 224, 3))
    
    interpreter.allocate_tensors()
    

def capture_image():
    stream = io.BytesIO()
    with picamera.PiCamera() as camera:
        camera.resolution = (640, 480)
        time.sleep(1)
        with picamera.array.PiRGBArray(camera) as stream: 
            camera.capture(stream, format='bgr')
            image = stream.array
            
    return image


def detect():
    global interpreter

    object_gray = None
    object_color = None

    for i in range(1):
        image = capture_image()
        object_gray, object_color  = image_util.define_object(image)
        
    results = image_classification.classify_image(interpreter,object_gray)
    label_id, prob = results[0]
    
    return label_id, object_color
    
    #cube, cylinder, prism, pyramid
    #blue, green, red, yellow
