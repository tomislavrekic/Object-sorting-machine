from tkinter import *
from tkinter import messagebox
from tkinter.constants import *
from PIL import Image,ImageTk
from time import sleep
import RPi.GPIO as GPIO
import serial
import threading

import object_color_detection

####CONSTANTS####
RB_FONT_SIZE=10
NAME_WIDTH=46
BUTTON_ON_COL='aquamarine'
BUTTON_OFF_COL='gray'
BUTTON_ERROR_COL='firebrick1'
#################

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(21,GPIO.IN)

UART=serial.Serial()
UART.baudrate=115200
UART.port='/dev/serial0'
UART.timeout=0
UART.open()
sleep(1)
UART.flushInput()
object_color_detection.setup()

message_list = ['1',0,0,0,0,0,0,0,0,'2',0,0,0,0,0,0,0,0,'3',0,0,0,0,0,0,0,0,0,'#']
color_list = ['blue', 'green', 'red', 'yellow']
shape_list = ['cube', 'cylinder', 'prism', 'pyramid']

object_mass = ''

def UART_Thread():
    global object_mass
    print("Starting UART_Thread")
    while True:
        sleep(2)
        if not object_mass:
            try:
                object_mass=UART.readline()
            except UnicodeDecodeError:
                print("WARNING: Corrupted data recived!")
            object_mass = ''

    print("Stopping UART_Thread")

trd1=threading.Thread(target=UART_Thread)

class Spremnik:
    def __init__(self,root,frame,name):
        self.root=root
        self.frame=frame
        self.oblik = IntVar()
        self.boja = IntVar()

        Label(frame, text="OBLIK").grid(row=1, column=0, pady=5)
        Label(frame, text="BOJA").grid(row=1, column=1, padx=25, pady=5)
        Label(frame, text="MASA").grid(row=1, column=2, padx=20, pady=5)

        tekst_btn_spremnik = " Spremnik "+str(name)
        self.btn_spremnik = Button(frame, text=tekst_btn_spremnik, command=self.ToggleSpremnik, bd=2, pady=3, width=NAME_WIDTH, fg='black', bg=BUTTON_OFF_COL)
        self.btn_spremnik.grid(row=0,column=0, columnspan=3)

        self.radio_btn_kocka = Radiobutton(frame, variable=self.oblik, value=1, text='kocka', state=DISABLED, width=6,  anchor=W, font=(None, RB_FONT_SIZE))
        self.radio_btn_kvadar = Radiobutton(frame, variable=self.oblik, value=3, text='kvadar', state=DISABLED, width=6, anchor=W, font=(None, RB_FONT_SIZE))
        self.radio_btn_piramida = Radiobutton(frame, variable=self.oblik, value=4, text='piramida', state=DISABLED, width=6, anchor=W, font=(None, RB_FONT_SIZE))
        self.radio_btn_valjak = Radiobutton(frame, variable=self.oblik, value=2, text='valjak', state=DISABLED, width=6, anchor=W, font=(None, RB_FONT_SIZE)) 
        self.radio_btn_kocka.grid(row=2, column=0)
        self.radio_btn_kvadar.grid(row=3, column=0)
        self.radio_btn_piramida.grid(row=4, column=0)
        self.radio_btn_valjak.grid(row=5, column=0)

        self.radio_btn_crvena = Radiobutton(frame, variable=self.boja, value=3, text='crvena', state=DISABLED, width=6, anchor=W, font=(None, RB_FONT_SIZE))
        self.radio_btn_plava = Radiobutton(frame, variable=self.boja, value=1, text='plava', state=DISABLED, width=6, anchor=W, font=(None, RB_FONT_SIZE))
        self.radio_btn_zelena = Radiobutton(frame, variable=self.boja, value=2, text='zelena', state=DISABLED, width=6, anchor=W, font=(None, RB_FONT_SIZE))
        self.radio_btn_zuta = Radiobutton(frame, variable=self.boja, value=4, text='zuta', state=DISABLED, width=6, anchor=W, font=(None, RB_FONT_SIZE))
        self.radio_btn_crvena.grid(row=2, column=1)
        self.radio_btn_plava.grid(row=3, column=1)
        self.radio_btn_zelena.grid(row=4, column=1)
        self.radio_btn_zuta.grid(row=5, column=1)

        self.label_masa_min = Label(frame, text="MIN", fg="gray")
        self.entry_masa_min = Entry(frame, width=5, state=DISABLED)
        self.label_masa_max = Label(frame, text="MAX", fg="gray")
        self.entry_masa_max = Entry(frame, width=5, state=DISABLED)
        self.label_masa_min.grid(row=2, column=2, sticky=W)
        self.entry_masa_min.grid(row=2, column=2)
        self.label_masa_max.grid(row=3, column=2, sticky=W)
        self.entry_masa_max.grid(row=3, column=2)
        self._container_state=False

    def ToggleSpremnik(self):
        self._container_state = not self._container_state
        if self._container_state == True:
            self.btn_spremnik.config(bg=BUTTON_ON_COL)
            self.radio_btn_kocka.config(state=NORMAL)
            self.radio_btn_kvadar.config(state=NORMAL)
            self.radio_btn_piramida.config(state=NORMAL)
            self.radio_btn_valjak.config(state=NORMAL)

            self.radio_btn_crvena.config(state=NORMAL)
            self.radio_btn_zelena.config(state=NORMAL)
            self.radio_btn_plava.config(state=NORMAL)
            self.radio_btn_zuta.config(state=NORMAL)

            self.entry_masa_max.config(state=NORMAL)
            self.entry_masa_min.config(state=NORMAL)
            self.label_masa_min.config(fg='black')
            self.label_masa_max.config(fg='black')
            self.entry_masa_min.insert(0, 0)
            self.entry_masa_max.insert(0, 999)

        elif self._container_state == False:
            self.btn_spremnik.config(bg=BUTTON_OFF_COL)
            self.radio_btn_kocka.config(state=DISABLED)
            self.radio_btn_kvadar.config(state=DISABLED)
            self.radio_btn_piramida.config(state=DISABLED)
            self.radio_btn_valjak.config(state=DISABLED)

            self.radio_btn_crvena.config(state=DISABLED)
            self.radio_btn_plava.config(state=DISABLED)
            self.radio_btn_zelena.config(state=DISABLED)
            self.radio_btn_zuta.config(state=DISABLED)

            self.entry_masa_min.delete(0, END)
            self.entry_masa_max.delete(0, END)
            self.entry_masa_max.config(state=DISABLED)
            self.entry_masa_min.config(state=DISABLED)
            self.label_masa_min.config(fg='grey')
            self.label_masa_max.config(fg='grey')
            
            self.oblik.set(0)
            self.boja.set(0)

    def get_container_state(self):
        return self._container_state



class App(Frame):
    def __init__(self, root, **kwargs):
        global trd1
        Frame.__init__(self,root,**kwargs)
        self.root = root
        self.container_list = []
        self.top_frame = LabelFrame()
        self.top_frame.place(in_=root, anchor='c', relx=.50, rely=.5)
        self.sub_frame_1 = LabelFrame(self.top_frame, padx=2, pady=3, bd=1)
        self.sub_frame_2 = LabelFrame(self.top_frame, padx=2, pady=3, bd=1)
        self.sub_frame_3 = LabelFrame(self.top_frame, padx=2, pady=3, bd=1)
        self.sub_frame_5 = Frame(self.top_frame, padx=3, pady=3, bd=3)

        self.container_1 = Spremnik(root,self.sub_frame_1,1)
        self.container_2 = Spremnik(root,self.sub_frame_2,2)
        self.container_3 = Spremnik(root,self.sub_frame_3,3)
        self.container_list = [self.container_1,self.container_2,self.container_3]

        self.sub_frame_1.grid(row=0, column=0)
        self.sub_frame_2.grid(row=1, column=0)
        self.sub_frame_3.grid(row=2, column=0)
        self.sub_frame_5.grid(row=3, column=0, columnspan=1)
  
        self.btn_pokreni = Button(self.sub_frame_5, command=self.Pokreni, text='Pokreni', fg='black', height=3, width=15)
        self.btn_zaustavi = Button(self.sub_frame_5, command=self.Zaustavi, text='Zaustavi', fg='black', height=3, width=15)
        self.btn_pokreni.grid(row=0, column=0, padx=50, pady=10)
        self.btn_zaustavi.grid(row=0, column=1, padx=50, pady=10)
        
        self.top_frame.pack()
        
        self.delay = 4
        self.flag = False
        self.detection_flag = False
        self.recived_masa = ""
        trd1.start()
        self.update()
    
    def update(self):
        global object_mass
        if self.flag == False and GPIO.input(21) == GPIO.HIGH:
            if self.detection_flag:
                self.flag=True
                
        if self.flag == True:
            shape = None
            color = None
            message = ''
            UART.flushOutput()
            
            shape, color = object_color_detection.detect()
            if color == None:
                shape, color = 7, 7
            else:
                print(color_list[color]+' '+shape_list[shape]) 
            shape+=1
            color+=1
            message = str(shape)+str(color)+'#'
            message = message.encode('utf_8')
            UART.write(message)
            self.flag=False
            
        sleep(0.3)
        self.after(self.delay, self.update)

    def Pokreni(self):
        message_list = ['1',0,0,0,0,0,0,0,0,'2',0,0,0,0,0,0,0,0,'3',0,0,0,0,0,0,0,0,1,'#']
        value_message = ''
        error_code = 0
        for con in self.container_list:
            if con.get_container_state():
                if int(con.entry_masa_min.get())<0 or int(con.entry_masa_max.get())>999 \
                    or int(con.entry_masa_min.get())>=int(con.entry_masa_max.get()):
                    con.btn_spremnik.config(bg=BUTTON_ERROR_COL)
                    error_code = 1

                elif con.btn_spremnik.cget('bg') == BUTTON_ERROR_COL:
                    con.btn_spremnik.config(bg=BUTTON_ON_COL)

        if error_code == 0:
            for i, con in enumerate(self.container_list):
                if con.get_container_state():
                    value_list = self.read_container(con)
                    for j, value in enumerate(value_list):
                        message_list[(i*9+1+j)]=value
                    
        if error_code == 1:
            msg_text = "Vrijednost mase mora biti u intervalu [0, 999]!"
            messagebox.showerror("Value error", msg_text)

        for char in message_list:
            value_message += str(char)
        self.detection_flag = True
        
        UART.write(value_message.encode())
        print(value_message)
        return
        

    def Zaustavi(self):
        message_list[27] = '0'
        value_message = ''
        for char in message_list:
            value_message += str(char)
        self.detection_flag = False
        UART.write(value_message.encode())
        print(value_message)
        return

    def read_container(self, container):
        ''' [oblik, boja, [min masa], [max masa]]'''
        container_value = []
        container_value.append(container.oblik.get())
        container_value.append(container.boja.get())
        
        min_mass = int(float(container.entry_masa_min.get()))
        max_mass = int(float(container.entry_masa_max.get()))
        
        min_split = [0, 0, 0]
        max_split = [0, 0, 0]
        for num in range(3):
            min_split[2-num] = int(min_mass%10)
            min_mass /= 10
        for num in range(3):
            container_value.append(min_split[num])
        for num in range(3):
            max_split[2-num] = int(max_mass%10)
            max_mass /= 10
        for num in range(3):
            container_value.append(max_split[num])

        con_str = ''
        for char in container_value:
            con_str += str(char)
        return con_str
                


if __name__ == '__main__':
    root = Tk()
    root.geometry("500x600")
    root.title("MAIN APP")
    root.bind_all("<1>", lambda event:event.widget.focus_set())
    app = App(root)
    app.pack()
    root.mainloop()